Steps to use

1. Unzip folder by rightlcicking on zipped folder and selecting extract here
2. Ensure Microsoft Word is installed on PC
3. Ensure template.docx is in the same folder that resumecreator.exe is located
4. Run resumecreator.exe
5. Enter info
6. DONE